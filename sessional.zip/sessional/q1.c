#include <stdio.h>
#include <string.h>

typedef struct grammar
{
	char LHS[5];
	char RHS[10];
}grammar;

int main(void)
{
	int no_of_grammars, i, flag = 0;
	
	printf("Enter no of grammars: ");
	scanf("%d", &no_of_grammars);
	
	grammar gr[no_of_grammars];
	
	printf("Enter grammars...\n");	
	for (i = 0; i < no_of_grammars; i++)
	{
		printf("Enter LHS part for grammar %d: ", i + 1);
		scanf("%s", gr[i].LHS);
		
		printf("Enter RHS part for grammar %d: ", i + 1);
		scanf("%s", gr[i].RHS);
	}
	
	int no_of_symbols;
	
	printf("Enter no of symbols: ");
	scanf("%d", &no_of_symbols);
	
	char c[no_of_symbols];
	
	printf("Enter symbols...\n");
	for (i = 0; i < no_of_symbols; i++)
		scanf(" %c", &c[i]);
		
	int k = 0;

	for (i = 0; i < no_of_grammars; i++)
	{
		for (int j = 0; gr[i].RHS[j] != '\0'; j++)
		{
			if (gr[i].RHS[j] == c[k])
			{
				printf("Valid production for the symbol: ");
				printf("%s --> %s\n", gr[i].LHS, gr[i].RHS);
				flag = 1;
				k++;
			}
			
			if (k == no_of_symbols)
				break;
		}
	}
	
	if (flag == 0)
	{
		printf("No production found for the given symbol...\n");
	}

	return 0;
}
