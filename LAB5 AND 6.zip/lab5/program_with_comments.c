#include <stdio.h>

// Comments
int main()
{
	/*It is a comment also
	printf("HEY");*/
	return 0;
}
