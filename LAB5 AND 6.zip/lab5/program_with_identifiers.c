#include <stdio.h>

int main(void)
{
	int a;
	int b = 25.3E+2;
	int c = 36;
	int d = 25.14;
	return 0;
}
