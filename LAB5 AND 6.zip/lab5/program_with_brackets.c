#include <stdio.h>

int main(void)
{
	(a+b={c+d}-[e*d]);
	return 0;
}
