#include <stdio.h>

int main(void)
{
	int s = 0;
	scanf("%d", &s);
	printf("%d", s);
	scanf("%d", &s);
	return 0;
}
