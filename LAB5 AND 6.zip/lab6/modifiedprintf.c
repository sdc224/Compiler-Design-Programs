#include <stdio.h>

int main(void)
{
	int s = 0;
	scanf("%d", &s);
	writef("%d", s);
	scanf("%d", &s);
	return 0;
}
