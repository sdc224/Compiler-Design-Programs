#include <stdio.h>
#include <stdlib.h>

int main(void)
{
	int length;
	int vowel_count = 0;	
	
	char string[100];
	
	printf("Enter string: ");
	scanf("%[^\n]", string);
	
	printf("Enter length of the string: ");
	scanf("%d", &length);
	
	for (int i = 0; i < length; i++)
	{
		if ((string[i] == 'a') || (string[i] == 'e') || (string[i] == 'i') || (string[i] == 'o') || (string[i] == 'u') || (string[i] == 'A') 				|| (string[i] == 'E') || (string[i] == 'I') || (string[i] == 'O') || (string[i] == 'U'))
			vowel_count++;
		
	}
	
	if (vowel_count >= 2)
		printf("String is valid\n");
	else
		printf("Not valid string\n");
	
	return 0;
}
